# vrne seznam imena hribov glede na dano gorovje *
# vrne najvišji hrib in višino v danem gorovju  *
# vrne poti, in vse lastnosti za dani hrib *
# vrne pot ,čas poti za dano zahtevnost
# uporabnik napiše min  in max nad. višine, program vrne vse hribe ki so v tem razponu *
#uporabnik napiše max/min čas poti ki bi hodil za izbran hrib, program izpiše ustrezno pot
#
# uporabnik se registrira in nato še prijavi; brez prijave ne more dati komentarja
# tabbela za vnašanje komentarjev (id,ime_gore, komentarji)


