import sqlite3 as dbapi

def uvozi():
    '''Uvozi in ustvari tabelo, če ta ne obstaja, ter vrne število elementov vsake tabele.'''
    
    #ustvari povezavo in kurzorzor
    povezava = dbapi.connect('Hribiaaaa.sqlite')
    kurzor = povezava.cursor()
    
    kurzor.execute("SELECT COUNT(*) FROM sqlite_master")
    if kurzor.fetchone() == (0, ):
        
        kurzor.execute("""CREATE TABLE Komentarji (
                            hrib TEXT NOT NULL,
                            komentar TEXT NOT NULL)""")
        
        kurzor.execute("""CREATE TABLE Gorovja (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ime VARCHAR NOT NULL,
                            najvišji_vrh VARCHAR NOT NULL)""")

        kurzor.execute("""CREATE TABLE Značilnosti (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            značilnost VARCHAR NOT NULL)""")

        kurzor.execute("""CREATE TABLE Oznaka(
                            kratica VARCHAR PRIMARY KEY,
                            stopnja VARCHAR NOT NULL)""")

        kurzor.execute("""CREATE TABLE Gore (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ime VARCHAR NOT NULL,
                            višina INTEGER DEFAULT "None",
                            geo_širina_dolžina VARCHAR DEFAULT "None",
                            id_gorovja INTEGER,
                            št_poti INTEGER DEFAULT "None",
                            FOREIGN KEY(id_gorovja)
                                REFERENCES Gorovja (id))""")

        kurzor.execute("""CREATE TABLE Pripada_značilnost (
                            gora INTEGER,
                            lastnost INTEGER,
                            FOREIGN KEY(gora)
                                REFERENCES Gorovja (id),
                            FOREIGN KEY(lastnost)
                                REFERENCES Značilnosti (id))""")

        kurzor.execute("""CREATE TABLE Poti (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            opis VARCHAR NOT NULL,
                            gora INTEGER,
                            čas INTEGER NOT NULL,
                            FOREIGN KEY(gora)
                                REFERENCES Gorovja (id))""")

        kurzor.execute("""CREATE TABLE Pripada_pot(
                            pot INTEGER,
                            zahtevnost VARCHAR,
                            FOREIGN KEY(pot)
                                REFERENCES Poti (id),
                            FOREIGN KEY(zahtevnost)
                                REFERENCES Oznaka (kratica))""")
        

        with open('Gorovja.txt', 'r') as data:
            for vrstica in data:
                a, b, c = vrstica[1:-2].split('; ')
                a = int(a)
                kurzor.execute("""INSERT INTO Gorovja (id, ime, najvišji_vrh) VALUES ({:d}, "{:s}", "{:s}");""".format(a, b, c))
            
        with open('Gore.txt', 'r') as data:
            for vrstica in data:
                a, b, c, d, e, f = vrstica[1:-2].split('; ')
                if ('e' in f) and ('e' in c):
                    kurzor.execute("""INSERT INTO Gore (id, ime, geo_širina_dolžina, id_gorovja) VALUES ({:d}, "{:s}", "{:s}", {:d});""".format(int(a), b, d, int(e)))
                elif 'e' in c:
                    #visina je None
                    kurzor.execute("""INSERT INTO Gore (id, ime, geo_širina_dolžina, id_gorovja, št_poti) VALUES ({:d}, "{:s}", "{:s}", {:d}, {:d});""".format(int(a), b, d, int(e), int(f)))
                elif 'e' in f:
                    kurzor.execute("""INSERT INTO Gore (id, ime, višina, geo_širina_dolžina, id_gorovja) VALUES ({:d}, "{:s}", {:d}, "{:s}", {:d});""".format(int(a), b, int(c), d, int(e)))
                else:
                    kurzor.execute("""INSERT INTO Gore (id, ime, višina, geo_širina_dolžina, id_gorovja, št_poti) VALUES ({:d}, "{:s}", {:d}, "{:s}", {:d}, {:d});""".format(int(a), b, int(c), d, int(e), int(f)))

        with open('Lastnosti.txt', 'r') as data:
            for vrstica in data:
                a, b = vrstica[1:-2].split('; ')
                kurzor.execute("""INSERT INTO Značilnosti (id, značilnost) VALUES ({:d}, "{:s}");""".format(int(a), b))

        with open('Oznaka.txt', 'r') as data:
            for vrstica in data:
                a, b = vrstica[1:-2].split('; ')
                kurzor.execute("""INSERT INTO Oznaka (kratica, stopnja) VALUES ("{:s}", "{:s}");""".format(a, b))


        with open('Poti.txt', 'r') as data:
            for vrstica in data:
                a, b, c, d = vrstica[1:-2].split('; ')
                kurzor.execute("""INSERT INTO Poti (id, opis, gora, čas) VALUES ({:d}, "{:s}", {:d}, {:d});""".format(int(a), b, int(c), int(d)))

        with open('Pripada_lastnosti.txt', 'r') as data:
            for vrstica in data:
                a, b = vrstica[1:-2].split('; ')
                kurzor.execute("""INSERT INTO Pripada_značilnost (gora, lastnost) VALUES ({:d}, {:d});""".format(int(a), int(b)))

        with open('Pripada_oznaka.txt', 'r') as data:
            for vrstica in data:
                a, b = vrstica[1:-2].split('; ')
                kurzor.execute("""INSERT INTO Pripada_pot (pot, zahtevnost) VALUES ({:d}, "{:s}");""".format(int(a), b))
        
    povezava.commit()
    kurzor.close()
    povezava.close()