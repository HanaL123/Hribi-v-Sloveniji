import re
import requests

with open('Povezave_hribov.txt') as data:
    slovar_lastnosti = dict()
    indeks = 1
    mn = set()
    for html in data:
        strip_url = html.strip()
        req = requests.get(strip_url)
        page = req.text
        
        slovar_lastnosti[indeks] = list()
        
        t = re.findall(r'<div class="g2"><b>Vrsta:</b>[^<]+</div>', page)
        prva = t[0].split('</b> ')[1]
        druga = prva.split('</div>')[0]
        rezultat=druga.split(', ')  # seznam vseh lastnosti hriba
        if rezultat[0] != '':
            for elt in rezultat:
                mn.add(elt)
                slovar_lastnosti[indeks].append(elt)
        indeks += 1
    print(slovar_lastnosti)


with open('Lastnosti.txt','w') as f:
    seznam = list(mn)
    slovar_ind = dict()
    j = 1
    for i in seznam:
        f.write('({:d}; {:s})\n'.format(j, i))
        slovar_ind[i] = j
        j+=1
    print(slovar_ind)


with open('Pripada_lastnosti.txt', 'w') as data:
    for kljuc_hrib in slovar_lastnosti.keys():
        for lastnost in slovar_lastnosti[kljuc_hrib]:
            data.write('({:d}; {:d})\n'.format(kljuc_hrib, slovar_ind[lastnost]))
            

    
    
    
