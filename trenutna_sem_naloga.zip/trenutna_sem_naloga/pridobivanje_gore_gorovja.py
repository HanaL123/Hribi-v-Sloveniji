import requests
import re

def najvisji_hribi(pov_gorovja):
    for i in re.findall(r'<a href="[^<]+">[^<]+</a></td><td class="vrt[AdZ]+">', pov_gorovja):
        i = i.split('>')[1]
        najvisji_hrib = i.split('<')[0]
        break
    return najvisji_hrib

def povezave_hribi(pov_gorovja):
    '''Vrne seznam url povezav hribov danega gorovja.'''
    sez_povezav = list()
    for i in re.findall(r'<a href="[^<]+">[^<]+</a></td><td class="vrt[AdZ]+">', pov_gorovja):
        j = i.split('href=')[1]
        j = j.split('>')[0]
        sez_povezav.append(j)
    return sez_povezav
    

def id_gorovij(pov_gorovja):
    '''Vrne pripadajoče ID števila.'''
    sez_id = list()
    for j in re.findall(r'<a href="[^<]+">[^<]+</a></td><td class="vrt[AdZ]+">', pov_gorovja):
        st = re.findall('\d+', j)[0]
        sez_id.append(st)
    return sez_id

def lastnosti_hriba(pov_hriba):
    '''Vrne širino in dolžino dane gore, število poti.'''
    try:
        niz = re.findall(r'<td><span id="kf0">[\d*\,\d*]+°N&nbsp;[\d*\,\d*]+°E</span></td>', pov_hriba)
        tab_lege = re.findall(r'\d+\,\d+',niz[0])  # [širina, dolžina]
    except:
        tab_lege = 'None'
    
    try:
        niz1= re.findall(r'<div class="g2"><b>Število poti:</b> <a class="moder" href="#poti">[\d*]+</a></div>', pov_hriba)
        st_poti = re.findall(r'[\d*]+', niz1[0])[1]
    except:
        st_poti = 'None'
    
    return tab_lege, st_poti


#GOROVJA imena
req1 = requests.get('https://www.hribi.net/gorovja')
page1 = req1.text
sez_imen = []
for i in re.findall(r'<a href="[^<]+">[^<]+</a>',page1):
    i = i.split('>')[1]
    ime = i.split('<')[0]
    sez_imen.append(ime)

sez_imen = sez_imen[2:-12]

datoteka_url = open('Povezave_hribov.txt', 'w')
datoteka = open('Gorovja.txt', 'w')
ind = 0
pr = 1

#tabela GOROVJA
with open('Povezave.txt') as f:
    for url in f:
        strip_url = url.strip()  #odstrani prelom končne vrstice
        req = requests.get(strip_url)
        page = req.text
        
        naj_hrib = najvisji_hribi(page)
        seznam_url_hribi = povezave_hribi(page)
        seznam_id = id_gorovij(page)        
        
        for elt in seznam_url_hribi:
            datoteka_url.write('https://www.hribi.net' + '{:s}\n'.format(elt[1:-1]))
        datoteka.write('({:s}; {:s}; {:s})\n'.format(seznam_id[ind], sez_imen[ind], naj_hrib))
        
        ind += 1
        pr +=1

datoteka_url.close()
datoteka.close()


datoteka_gore = open('Gore.txt', 'w')
with open('Povezave_hribov.txt') as data:
    i = 1
    for html in data:
        strip_url = html.strip()  #odstrani prelom končne vrstice
        req = requests.get(strip_url)
        page = req.text
        
        ime = re.findall(r'<div style="float:left;"><h1>[^<]+</h1></div>', page)
        ime = re.split(r'<h1>', ime[0])[1]
        ime = re.split(r'<', ime)[0]
        
        try:
            visina = re.findall(r'<div class="g2"><b>Višina:</b> [1-9][0-9]+&nbsp;m</div>', page)
            visina = re.split(r'>', visina[0])[3][1:-12]
        except:
            visina = 'None'
        
        id_gorovja = re.split('/', strip_url)[-2]
        lega, b = lastnosti_hriba(page)
        if lega is not None:
            lega = lega[0] + '°N/' + lega[1] + '°E'
        
        datoteka_gore.write('({:d}; {:s}; {:s}; {:s}; {:s}; {:s})\n'.format(i, ime, visina, lega, id_gorovja, b))
        i+=1
        

datoteka_gore.close()


