import sqlite3 as dbapi

povezava = dbapi.connect('Hribiaaaa.sqlite')

def isci_hribe(gorovje):
    '''V bazi poišče vse hribe glede na podano gorovje.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT Gore.ime FROM Gorovja JOIN Gore ON (Gorovja.id = Gore.id_gorovja) WHERE Gorovja.ime LIKE ?", ['%' + gorovje + '%'])
    hribi = kurzor.fetchall()
    kurzor.close()
    return hribi

def isci_vse_poti():
    '''Funkcija, ki poišče vse poti v bazi.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT opis FROM Poti")
    pot = kurzor.fetchall()
    kurzor.close()
    return pot

def isci_vse_hribe():
    '''Funkcija, ki poišče vse hribe v bazi.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT ime FROM Gore")
    pot = kurzor.fetchall()
    kurzor.close()
    return pot



def isci_naj_deset_hrib(gorovje):
    '''V bazi poišče ime in višino deset najvišjih hribov danega gorovja.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT Gore.ime, višina FROM Gore JOIN Gorovja ON (Gorovja.id = Gore.id_gorovja) WHERE Gorovja.ime LIKE ? LIMIT 10" , ['%' + gorovje + '%'])
    vr = kurzor.fetchall()
    kurzor.close()
    return vr


def isci_poti(hrib):
    '''V bazi poišče vsa imena in čase poti danega hriba in vrne seznam.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT opis, čas FROM Poti WHERE Poti.gora = (SELECT id FROM Gore WHERE ime LIKE ?)", ['%' + hrib + '%'])
    poti = kurzor.fetchall()
    kurzor.close()
    return poti

def isci_najkrajso(hrib):
    '''V bazi poišče ime najkrajše poti za določen hrib in čas te poti.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT opis, min(čas) FROM Poti WHERE Poti.gora = (SELECT id FROM Gore WHERE ime LIKE ?)", ['%' + hrib + '%'])
    poti = kurzor.fetchall()
    kurzor.close()
    return poti

def isci_najdaljso(hrib):
    '''V bazi poišče ime najkrajše poti za določen hrib in čas te poti.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT opis, max(čas) FROM Poti WHERE Poti.gora = (SELECT id FROM Gore WHERE ime LIKE ?)", ['%' + hrib + '%'])
    poti = kurzor.fetchall()
    kurzor.close()
    return poti

def interval_nadmorske(gorovje, min_visina, max_visina, znacilnost):
    '''Poišče in vrne vsa hribovja, ki so v razponu med danima nadmorskima višinama v danem gorovju.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT Gore.ime, Gore.višina, Gore.geo_širina_dolžina, Gore.št_poti FROM Gore JOIN Gorovja ON (Gore.id_gorovja = Gorovja.id) JOIN Pripada_značilnost ON (Pripada_značilnost.gora = Gore.id) JOIN Značilnosti ON (Značilnosti.id = Pripada_značilnost.lastnost) WHERE Gore.id_gorovja = (SELECT Gorovja.id FROM Gorovja WHERE ime LIKE ?) AND (Gore.višina BETWEEN ? AND ?) AND (značilnost LIKE ?)", [gorovje, min_visina, max_visina, znacilnost])
    seznam = kurzor.fetchall()
    kurzor.close()
    return seznam

def isci_znacilnosti(hrib):
    '''Poišče in vrne seznam vse značilnosti danega hriba, ki si jih lahko ogledamo.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT značilnost FROM Značilnosti JOIN Pripada_značilnost ON (Značilnosti.id = Pripada_značilnost.lastnost) JOIN Gore ON (Pripada_značilnost.gora = Gore.id) WHERE Gore.ime LIKE ? ", [hrib])
    lastnosti = kurzor.fetchall()
    kurzor.close()
    return lastnosti



def isci_zahtevnost_pot(pot):
    '''Funkcija, ki poišče in vrne zahtevnost poti.'''
    kurzor = povezava.cursor()
    kurzor.execute("SELECT Oznaka.stopnja FROM Oznaka JOIN Pripada_pot ON (Oznaka.kratica = Pripada_pot.zahtevnost) JOIN Poti ON (Pripada_pot.pot = Poti.id) WHERE Poti.opis LIKE ?", [pot])
    zahtevnost = kurzor.fetchall()
    kurzor.close()
    return zahtevnost
    
def interval_casa_poti(gorovje, min_cas, max_cas):
    kurzor = povezava.cursor()
    kurzor.execute("SELECT Gore.ime, Poti.opis, Poti.čas FROM Gore JOIN Poti ON (Gore.id = Poti.gora) JOIN Gorovja ON (Gore.id_gorovja = Gorovja.id) WHERE Gorovja.ime = ? AND Poti.čas BETWEEN ? AND ?", [gorovje, min_cas, max_cas])
    seznam = kurzor.fetchall()
    kurzor.close()
    return seznam

def dodaj_komentar(hrib, tekst):
    kurzor = povezava.cursor()
    kurzor.execute("INSERT INTO Komentarji (hrib, komentar) VALUES (?, ?)", [hrib, tekst])
    povezava.commit()
    kurzor.close()


def izpisi_komentarje():
    kurzor = povezava.cursor()
    kurzor.execute("SELECT * FROM Komentarji")
    seznam_komentarjev = kurzor.fetchall()
    kurzor.close()
    return seznam_komentarjev




    
    
    
    
    

    
    
    
    

