from bottle import get, route, run, template, request
from model import *

@route('/')
def pozdrav():
    return template('zacetna.html')

@route('/meni/poiskal_deset_najvisjih/')
def poiskal_deset():
    return template('deset_najvisjih.html')

@route('/meni/poiskal_pot/')
def poiskal_poti():
    hribi = isci_vse_hribe()
    return template('poiskal_poti.html', hribi = hribi)


@route('/meni/poiskal_hrib/')
def poiskal_hrib():
    return template('hribi_gorovje.html')

@route('/meni/poiskal_lastnost_hriba/')
def poiskal_lastnost():
    hribi = isci_vse_hribe()
    return template('lastnost_hriba.html', hribi = hribi)

@route('/meni/poiskal_hrib_pot/')
def poiskal_hrib():
    return template('hrib_pot.html')

@route('/poiskal_hrib_poti/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    minimalni = request.query.iskalni_niz2
    maksimalni = request.query.iskalni_niz3
    hribi = interval_casa_poti(iskalni_niz, minimalni, maksimalni)
    return template('rezultati_hriba_pozi', iskalni_niz = iskalni_niz, iskalni_niz2 = minimalni, iskalni_niz3 = maksimalni, hribi = hribi)


@route('/poiskal_lastnost_hriba/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    hribi = isci_znacilnosti(iskalni_niz)
    return template('rezultati_znacilnosti_hriba', iskalni_niz = iskalni_niz, hribi = hribi)
    

@route('/poiskal_pot/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    vse_poti = isci_poti(iskalni_niz) 
    return template('rezultati_vse_poti_hriba', iskalni_niz = iskalni_niz, vse_poti = vse_poti)

@route('/poiskal_pot_najkrajsa/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    najkrajsa = isci_najkrajso(iskalni_niz)
    return template('rezultat_najkrajse_poti_hriba', iskalni_niz = iskalni_niz, najkrajsa = najkrajsa)

@route('/poiskal_pot_najdaljsa/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    najdaljsa = isci_najdaljso(iskalni_niz)
    return template('rezultat_najdaljse_poti_hriba', iskalni_niz = iskalni_niz, najdaljsa = najdaljsa)

@route('/meni/izvedel_zahtevnost_poti/')
def poiskal_hrib():
    poti = isci_vse_poti()
    return template('izvedel_zahtevnost.html', poti = poti)

@route('/pridobi_zahtevnost_poti/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    hribi = isci_zahtevnost_pot(iskalni_niz)
    return template('rezultati_zahtevnosti_poti', iskalni_niz = iskalni_niz, hribi = hribi)


@route('/poiskal_deset_najvisjih/rezultati')
def isci1():
    iskalni_niz = request.query.iskalni_niz
    hribi = isci_naj_deset_hrib(iskalni_niz)
    return template('rezultati_iskanja_hribov', iskalni_niz = iskalni_niz, hribi = hribi)

@route('/poiskal_hrib/rezultati')
def isci2():
    gorovje = request.query.iskalni_niz
    minimalna = request.query.iskalni_niz2
    maksimalna = request.query.iskalni_niz3
    znacilnost = request.query.iskalni_niz4
    hribi2 = interval_nadmorske(gorovje, minimalna, maksimalna, znacilnost)
    return template('rezultati_hribov', iskalni_niz = gorovje, iskalni_niz2 = minimalna, iskalni_niz3 = maksimalna, iskalni_niz4 = znacilnost, hribi2 = hribi2)


@route('/meni/pustil_vtis/')
def pusti_vtis():
    hribi = isci_vse_hribe()
    return template('pustil_komentar.html', hribi = hribi)

@route('/profil_hriba/rezultati')

def isci_profil():
    hrib = request.query.iskalni_niz
    tekst = request.query.iskalni_niz2
    dodaj_komentar(hrib, tekst)
    return template('zacetna.html')

@route('/meni/komentarji/')

def komentiraj():
    seznam = izpisi_komentarje()
    return template('komentarji.html', seznam = seznam)















run(debug=True)