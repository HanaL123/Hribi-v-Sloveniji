from model import *
from pomozne_funkcije import *

def vnesi_izbiro(moznosti):
    """
    Uporabniku da na izbiro podane možnosti.
    """
    moznosti = list(moznosti)
    for i, moznost in enumerate(moznosti, 1):
        print(f'{i}) {moznost}')
    izbira = None
    while True:
        try:
            izbira = int(input('> ')) - 1
            return moznosti[izbira]
        except (ValueError, IndexError):
            print("Napačna izbira!")


@prekinitev         
def izpisi_poti():
    '''Funkcija, ki izpiše vse poti in čas za podani hrib.'''
    ime_hriba = input('Poti katerega hriba te zanimajo? ')
    poti = isci_poti(ime_hriba)
    if len(poti) == 0:
        print('Tega hriba ne najdem. Poskusi znova.')
    elif len(poti) == 1:
        print(('{:<70s} | {:>7s}').format('Ime poti: ','Čas hoje: '))
        print(('{:<70s} | {:>7s}').format('~~~~~~~~~','~~~~~~~~~~~~'))
        for k in poti:
            print(('{:<70s} | {:>7d} min').format(k[0],k[1]) ) #potrebno preoblikovati minute v ure in minute
    else:
        dolzina = input('Našel sem več poti. Želiš izpisane vse poti, najdaljšo ali najkrajšo pot po času? ')
        if dolzina.lower() in {'najkrajšo','najkrajša','najkrajsa', 'najkrajso'}:    #potrebno navesti več možnost, ki jih lahko uporabnik vnese (najkrajša, najkrajšo, Najkrajšo...)
            s1 = isci_najkrajso(ime_hriba)
            print(('{:<70s} |{:>7s}').format('Ime poti: ','Čas hoje: '))
            print(('{:<70s} {:>7s}').format('~~~~~~~~~~','~~~~~~~~~~~'))
            for i in s1:
                print(('{:<70s} |{:>7d} min').format(i[0],i[1]))
        if dolzina.lower() in {'najdaljso','najdaljsa','najdaljšo', 'najdaljša'}:
            s2 = isci_najdaljso(ime_hriba)
            print(('{:<70s} |{:>7s}').format('Ime poti: ','Čas hoje: '))
            print(('{:<70s} {:>7s}').format('~~~~~~~~~~~',' ~~~~~~~~~~'))
            for j in s2:
                print(('{:<70s} |{:>7d} min').format(j[0],j[1]))
        if dolzina == 'vse':
            print(('{:<70s} | {:>7s}').format('Ime poti: ','Čas hoje: '))
            print(('{:<70s}  {:>7s}').format('~~~~~~~~~~~','~~~~~~~~~~'))
            for h in poti:
                print(('{:<70s} |{:>7d} min').format(h[0],h[1]))
    print('___________________________')


    
@prekinitev
def izpisi_deset_najvecjih_hribov():
    '''Funkcija, ki izpiše deset najvišjih hribov za dano gorovje.'''
    for kljuc, vr in hribovja.items():
        print('{:>10d} | {:s}'.format(kljuc, vr))
    st_hribovja= int(input('Deset najvišjih hribov katerega gorovja te zanimajo? Za izbrano gorovje vpiši pripadajočo število: '))
    try:
        #da ne vsebuje dodatnih smeti
        if st_hribovja in range(1, 11):
            gorovje = hribovja[st_hribovja]
            odg = isci_naj_deset_hrib(gorovje)
            print(('{:>80s} | {:<10}').format('Ime hriba: ','Nadmorska višina: '))
            print(('{:>80s}  {:<10}').format('~~~~~~~~~~~~','~~~~~~~~~~~~~~~~~~~'))
            for i in odg:
                print(('{:>80s} | {:<7d} m').format(i[0],i[1]))
    except:
            print('Ime gorovja v Sloveniji ne obstaja.')
            izpisi_deset_najvecjih_hribov()
    print('___________________________')
            
            
            
@prekinitev
def izpisi_hribove():
    '''Funkcija, ki izpiše vse podatke o hribu glede na dano gorovje, interval nadmorske višine in značilnosti, ki ni jih želeli videti.'''
    print('Za izbrano gorovje vpiši pripadajočo število:')
    for kljuc, vr in hribovja.items():
        print('{:>10d} | {:s}'.format(kljuc, vr))
    st_hribovja = input('Katero gorovje bi želel obiskati? ')
    try:
        #da ne vsebuje dodatnih smeti
        int(st_hribovja)
        if int(st_hribovja) in range(1, 11):
            višina = minimalna_visina()
            odg1 = interval_nadmorske(hribovja[int(st_hribovja)], višina[0], višina[1][0], slovar_znacilnosti[int(višina[1][1])])
            if len(odg1) == 0:
                print('Takšnega hriba v Sloveniji ni.')

            else:
                print('{:>50s} | {:>15s}  | {:>20s} | {:>10s}'.format('Hribi: ','Nadmorska višina v metrih: ', 'Geografska širina in višina: ', 'Število poti: '))
                print('{:>50s} {:>21s}  {:>28s} {:>16s}'.format('~~~~~~~~~','  ~~~~~~~~~~~~~~~~~~~~~~~~~~~', ' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~', '  ~~~~~~~~~~~~~~'))
                for i in odg1:
                    print('{:>50s} | {:>26d} m | {:>29s} | {:>10d}'.format(i[0],i[1],i[2],i[3]))                
        else:
            print('Število ni pravilno.')
            izpisi_hribove()
    except:
        print('Vnešeni podatek ni pravilen.')
        izpisi_hribove()
    print('___________________________')
                    
            
            
            
            
@prekinitev
def izpisi_zahtevnosti_poti():   
    pot = input('Za katero pot te zanima zahtevnost hoje? ')
    tab1 = []
    for i in isci_vse_poti():
        tab1.append(i[0])
    if pot not in tab1:
        print('Željena pot ne obstaja: ')
    else:
        print('{} je {} {}.'.format(pot, isci_zahtevnost_pot(pot)[0][0], isci_zahtevnost_pot(pot)[1][0]))
    

    print('___________________________')
    
    
@prekinitev
def izpisi_lastnosti_hriba(): 
    hrib = input('Kateri hrib v Sloveniji želiš obiskati? ')
    tab = []
    for i in isci_vse_hribe():
        tab.append(i[0])
    if hrib not in tab:
        print('Željeni hrib ne obstaja.')
    else:
        for j in isci_znacilnosti(hrib):
            print('~ {}'.format(j[0]))
    print('___________________________')
        

@prekinitev
def izpisi_hrib_in_pot():
    '''Funkcija, ki izpiše hrib in pot glede na dane podatke.'''
    print('Za izbrano gorovje vpiši pripadajočo število:')
    for kljuc, vr in hribovja.items():
        print('{:>10d} | {:s}'.format(kljuc, vr))
    st_hribovja = input('Katero gorovje bi želel obiskati? ')
    int(st_hribovja)
    if int(st_hribovja) in range(1, 11):
        min_cas_hoje = input('Vpiši minimalno število minut, ki si jih pripravljen prehoditi: ')
        max_cas_hoje = input('Vpiši maksimalno število minut, ki si jih pripravljen prehoditi: ')
        rez = interval_casa_poti(hribovja[int(st_hribovja)], min_cas_hoje, max_cas_hoje)
        print('{:>60s} | {:<10s} | {:>10s}'.format('Ime hriba: ', 'Čas poti: ', 'Opis poti: '))
        print('{:>60s}  {:<10s} {:>10s}'.format('~~~~~~~~~~~~~ ', '~~~~~~~~~~~', '  ~~~~~~~~~~~'))
        for i in rez:
            print('{:>60s} | {:<10d} min | {:>10s}'.format(i[0], i[2], i[1]))
    print('___________________________')
                                   
            
            
            
def domov():
    """
    Pozdravi pred izhodom.
    """
    print('Adijo!')


class GlavniMeni(Meni):
    """
    Izbire v glavnem meniju.
    """
    IZPISI_HRIBOVE = ('Poiskal hrib', izpisi_hribove)
    ISKAL_POT = ('Poiskal pot', izpisi_poti)
    IZPISAL_ZAHTEVNOST_POTI = ('Izvedel zahtevnost poti ', izpisi_zahtevnosti_poti)
    POISKAL_LASTNOST_HRIBA = ('Poiskal lastnost hriba ', izpisi_lastnosti_hriba)
    POISKAL_HRIB_IN_POT = ('Poiskal hrib in pot  ', izpisi_hrib_in_pot)
    POISKAL_10_NAJVISJIH_HRIBOV = ('Poiskal 10 najvišjih hribov in njihove nadmorske višine za določeno gorovje', izpisi_deset_najvecjih_hribov)
    SEL_DOMOV = ('Šel domov', domov)


@prekinitev
def glavni_meni():
    """
    Prikazuje glavni meni, dokler uporabnik ne izbere izhoda.
    """
    print('___________________________')
    print('Pozdravljen v bazi hribov!')
    while True:
        print('Kaj bi rad delal?')
        izbira = vnesi_izbiro(GlavniMeni)
        izbira.funkcija()
        if izbira == GlavniMeni.SEL_DOMOV:
            return


glavni_meni()  



