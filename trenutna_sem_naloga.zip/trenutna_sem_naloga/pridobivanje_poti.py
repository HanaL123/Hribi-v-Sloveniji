import requests
import re
from pomozne_funkcije import oblika_casa

dat = open('Poti.txt', 'w')

with open('Povezave_hribov.txt') as file:
    j = 1
    ind_gore = 1
    for html in file:
        strip_url = html.strip()
        req = requests.get(strip_url)
        page = req.text
        
        sez = list()
    #  '<tr class="trG[0|1]"><td class="tdG"><a href="[^<]+">[^<]+</a></td><td class="tdG"><a href="/[^<]+">[^<]+</a></td><td class="tdG"><a href="[^<]+">[^<]+</a></td></tr>'
        t = re.findall(r'<tr class="trG[0|1]"><td class="tdG"><a href="[^<]+">[^<]+</a></td><td class="tdG"><a href="/[^<]+">[^<]+</a></td><td class="tdG"><a href="[^<]+">[^<]+</a></td></tr>', page)
        for i in t:
            #niz = re.findall(r'[^<]+', i)
            #opis = niz[2].split('>')  #[1] ime poti
            j1 = i.split('>')
            i, c = (j1[3][:-3], j1[7][:-3])
            sez.append((i, c))
        
        for pot in sez:
            ime, cas = pot
            cas1 = oblika_casa(cas)
            dat.write('({:d}; {:s}; {:d}; {:d})\n'.format(j, ime, ind_gore, cas1))
            j += 1
        
        ind_gore += 1

dat.close()
