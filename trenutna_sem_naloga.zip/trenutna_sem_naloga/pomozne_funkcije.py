from functools import wraps
from enum import Enum

class Meni(Enum):
    """
    Razred za izbire v menijih.
    """
    def __init__(self, ime, funkcija):
        """
        Konstruktor izbire.
        """
        self.ime = ime
        self.funkcija = funkcija

    def __str__(self):
        """
        Znakovna predstavitev izbire.
        """
        return self.ime
    
def oblika_casa(string):
    '''Funkcija, ki spremeni čas oblike %h %min v število minut.'''
    if 'h' in string and 'min' in string:
        s1 = int(string.split(' h ')[0])
        s2 = string.split(' h ')[1]
        s3 = int(s2.split(' min')[0])
        cas = s1 * 60 + s3
    elif 'h' in string and 'min' not in string:
        s2 = int(string.split(' h')[0])
        cas = s2 * 60
    else:
        s2 = int(string.split(' min')[0])
        cas = s2
    return cas
        

hribovja = {1: 'Goriško, Notranjsko in Snežniško hribovje', 2: 'Julijske Alpe', 3: 'Kamniško Savinjske Alpe',
           4: 'Karavanke', 5: 'Pohorje, Dravinjske gorice in Haloze', 6: 'Polhograjsko hribovje in Ljubljana',
           7: 'Posavsko hribovje in Dolenjska', 8: 'Prekmurje', 9: 'Škofjeloško, Cerkljansko hribovje in Jelovica',
           10: 'Strojna, Košenjak, Kozjak in Slovenske gorice'}

slovar_znacilnosti = {1: 'sedlo', 2: 'slap', 3: 'jezero', 4: 'planina', 5: 'koča', 6: 'vrh', 7: 'cerkev', 8: 'bivak'}



def minimalna_visina():
    min_visina = input('Vnesi minimalno nadmorsko višino, ki jo želiš prehoditi: ')
    try:
        c = int(min_visina)
        if c > 0:
            najvisje = maksimalna_visina()
            return [min_visina, najvisje]
        else:
            print('Vnešena višina ni pozitivno celo število.')
            minimalna_visina()
    except:
        print('Nepravilni podatek.')
        minimalna_visina()
            
def maksimalna_visina():
    max_visina = input('Vnesi maksimalno nadmorsko višino, ki jo želiš prehoditi: ')
    try:
        b = int(max_visina)
        if b > 0:
            for kljuc, vr in slovar_znacilnosti.items():
                print('{:>10d} | {:s}'.format(kljuc, vr))
            st_znacilnosti = kaj_videti()
            return [max_visina, st_znacilnosti]
        else:
            print('Vnešena višina ni pozitivno celo število.')
            maksimalna_visina()
    except:
        print('Nepravilni podatek.')
        maksimalna_visina()

def kaj_videti():
    znacilnost = input('Katero eno značilnost izmed naštetih bi želel videti? ')
    try:
        a = int(znacilnost)
        if a in range(1, 9):
            return znacilnost
        else:
            print('Vnešeni podatek ni pravilen.')
            kaj_videti()
    except:
        print('Nepravilni podatek.')
        kaj_videti()



def prekinitev(fun):
    """
    Dekorator za obravnavo prekinitev s Ctrl+C.
    """
    @wraps(fun)
    def funkcija(*largs, **kwargs):
        try:
            fun(*largs, **kwargs)
        except KeyboardInterrupt:
            print("\nPrekinitev!")
    return funkcija