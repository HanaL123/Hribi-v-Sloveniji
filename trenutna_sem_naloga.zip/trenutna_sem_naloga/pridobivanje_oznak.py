import requests
import re

with open('Povezave_hribov.txt') as file:
    slovar = dict()
    mnozica = set()
    i = 1
    for html in file:
        strip_url = html.strip()
        req = requests.get(strip_url)
        page = req.text

        t = re.findall(r'<tr class="trG[0|1]"><td class="tdG"><a href="[^<]+">[^<]+</a></td><td class="tdG"><a href="/[^<]+">[^<]+</a></td><td class="tdG"><a href="[^<]+">[^<]+</a></td></tr>',page)
        for j in t:
            try:
                j1 = j.split('>')[11]
                j2 = j1.split('<')[0]
                j3 = j2.split(',')[0] # 'lahka oznacena pot'
                if j3 != 'ni podatka':
                    vrsta = j3.split(' ')[-1]
                    a = j3[::-1].split(' ', 1)
                    a = a[1]
                    opisek = a[::-1]
                    mnozica.add(opisek)
                    mnozica.add(vrsta)
                    slovar[i] = {opisek, vrsta}
                i += 1
                
            except: continue

slovar_kratic = dict()

with open('Oznaka.txt', 'w') as dat:
    for o in mnozica:
        if o == 'pot':
            dat.write('({:s}; {:s})\n'.format('P',o))
            slovar_kratic[o] = 'P'
        elif o == 'alpinistični':
            dat.write('({:s}; {:s})\n'.format('ALP',o))
            slovar_kratic[o] ='ALP'
        elif o == 'vzpon':
            dat.write('({:s}; {:s})\n'.format('V',o))
            slovar_kratic[o] = 'V'
        elif o == 'steza':
            dat.write('({:s}; {:s})\n'.format('S',o))
            slovar_kratic[o] = 'S'
        elif o == 'brezpotje':
            dat.write('({:s}; {:s})\n'.format('B',o))
            slovar_kratic[o] = 'B'
        elif o == 'delno zahtevna označena':
            dat.write('({:s}; {:s})\n'.format('DZO',o))
            slovar_kratic[o] = 'DZO'
        elif o == 'zelo zahtevno':
            dat.write('({:s}; {:s})\n'.format('ZZ',o))
            slovar_kratic[o] = 'ZZ'
        elif o == 'zelo zahtevna označena':
            dat.write('({:s}; {:s})\n'.format('ZZO',o))
            slovar_kratic[o] = 'ZZO'
        elif o == 'zahtevna označena':
            dat.write('({:s}; {:s})\n'.format('ZO',o))
            slovar_kratic[o] = 'ZO'
        elif o == 'lahka označena':
            dat.write('({:s}; {:s})\n'.format('LO',o))
            slovar_kratic[o] = 'LO'
        elif o == 'lahka neoznačena':
            dat.write('({:s}; {:s})\n'.format('LNO',o))
            slovar_kratic[o] = 'LNO'
        elif o == 'zelo zahtevna neoznačena':
            dat.write('({:s}; {:s})\n'.format('ZZNO',o))
            slovar_kratic[o] = 'ZZNO'
        elif o == 'izjemno zahtevna označena':
            dat.write('({:s}; {:s})\n'.format('IZO',o))
            slovar_kratic[o] = 'IZO'
        elif o == 'zahtevno':
            dat.write('({:s}; {:s})\n'.format('Z',o))
            slovar_kratic[o] = 'Z'
        elif o == 'lahko':
            dat.write('({:s}; {:s})\n'.format('L',o))
            slovar_kratic[o] = 'L'
        elif o == 'zahtevna neoznačena':
            dat.write('({:s}; {:s})\n'.format('ZNO',o))
            slovar_kratic[o] = 'ZNO'
        elif o == 'delno zahtevna neoznačena':
            dat.write('({:s}; {:s})\n'.format('DZNO',o))
            slovar_kratic[o] = 'DZNO'
        
        
with open('Pripada_oznaka.txt', 'w') as data:
    for id_poti in slovar.keys():
        for elt in slovar[id_poti]:
            data.write('({:d}; {:s})\n'.format(id_poti, slovar_kratic[elt]))
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        